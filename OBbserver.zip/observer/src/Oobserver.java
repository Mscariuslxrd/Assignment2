public interface Oobserver
{
    void update(String message);
}