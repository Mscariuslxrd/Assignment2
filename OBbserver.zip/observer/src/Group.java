import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class Group {
    private Logger LOGGER = Logger.getLogger(Group.class.getName());

    private List messages;
    private List observers;

    public Group() {
        observers = new ArrayList<>();
        messages = new ArrayList<>();
    }

    public void add_Observer(Oobserver observer) {
        observers.add(observer);
    }

    public void remove_Observer(Oobserver observer) {
        observers.remove(observer);
    }

    public void add_Message(String message) {
        messages.add(message);
        LOGGER.info(String.format("Chat get new message: %s", message));
        //notify_Observers(message);
    }

    /*private void notify_Observers(String message) {
        for (Oobserver observer : observers) {
            observer.update(message);
        }*/
    }




