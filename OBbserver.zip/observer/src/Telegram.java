public class Telegram {
    public static void main(String[] args) {
        User user = new User();


        Group message = new Group();
        message.add_Observer(user);

        message.add_Message("Hi");

        message.remove_Observer(user);
        message.add_Message("Buy-buy");
    }
}